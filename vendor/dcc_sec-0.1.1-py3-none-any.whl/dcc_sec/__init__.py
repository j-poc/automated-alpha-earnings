"""Thin authenticated SEC client; provider acquisition belongs to the service SDK."""
from .client import (SharedSecError, SharedResponse, archive_root, bind_sdk,
                     connection, fetch_bytes, quota_root, raw_client)

__all__ = ['SharedSecError', 'SharedResponse', 'archive_root', 'bind_sdk',
           'connection', 'fetch_bytes', 'quota_root', 'raw_client']
