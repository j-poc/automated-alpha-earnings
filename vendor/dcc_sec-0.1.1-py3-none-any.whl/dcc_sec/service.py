"""Single-owner authenticated acquisition API backed by the pinned SEC SDK."""
import argparse
import base64
import hashlib
import hmac
import json
import os
import re
import secrets
import sqlite3
import time
from contextlib import closing
from dataclasses import asdict
from pathlib import Path
from datetime import datetime, timezone
from typing import Literal


def private_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    temporary = path.with_name(path.name + '.' + secrets.token_hex(4) + '.tmp')
    descriptor = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(descriptor, 'w') as output:
        json.dump(data, output, indent=2)
        output.write('\n')
        output.flush()
        os.fsync(output.fileno())
    temporary.replace(path)


def provision(home, projects, port=8931):
    home = Path(home).resolve()
    path = home / 'service.json'
    settings = json.loads(path.read_text()) if path.exists() else {'schema_version': 1, 'tokens': {}}
    for app, project in projects.items():
        config_path = Path(project) / '.dcc-sec.json'
        existing = json.loads(config_path.read_text()) if config_path.exists() else {}
        token = existing.get('token') if existing.get('app') == app and existing.get('url') == f'http://127.0.0.1:{port}' else None
        token = token or secrets.token_urlsafe(36)
        settings['tokens'][app] = hashlib.sha256(token.encode()).hexdigest()
        private_json(config_path, {'schema_version': 'dcc-sec.connection.v1', 'app': app,
                                  'url': f'http://127.0.0.1:{port}', 'token': token,
                                  'raw_root': str(home / 'sec-raw'), 'quota_root': str(home / 'sec-quota')})
        ignore = Path(project) / '.gitignore'
        previous = ignore.read_text() if ignore.exists() else ''
        if '.dcc-sec.json' not in previous.splitlines():
            ignore.write_text(previous.rstrip() + '\n.dcc-sec.json\n')
    private_json(path, settings)


def create_app(home, *, raw_factory=None):
    from fastapi import FastAPI, Header, Request
    from fastapi.responses import JSONResponse
    from pydantic import BaseModel, ConfigDict, Field
    from public_investment_data import DataError
    from public_investment_data.sec_raw import SecRawClient

    root = Path(home).resolve()

    # Initialize once before accepting traffic. Concurrent first constructors can
    # otherwise observe the SDK archive's partly-created schema.
    owner = raw_factory() if raw_factory is not None else SecRawClient(
        root=root / 'sec-raw', quota_root=root / 'sec-quota',
        user_agent='DCC shared SEC research dreamcllectr@gmail.com')

    def raw():
        return owner

    def authorize(authorization):
        if not isinstance(authorization, str) or not authorization.startswith('Bearer '):
            return None
        digest = hashlib.sha256(authorization[7:].encode()).hexdigest()
        settings = json.loads((root / 'service.json').read_text())
        return next((app for app, value in settings['tokens'].items() if hmac.compare_digest(value, digest)), None)

    class Fetch(BaseModel):
        model_config = ConfigDict(extra='forbid', strict=True)
        url: str = Field(min_length=1, max_length=4096)
        max_bytes: int = Field(default=64 * 1024 * 1024, ge=1, le=8 * 1024**3)
        timeout_seconds: int = Field(default=25, ge=1, le=300)
        ttl_seconds: int = Field(default=300, ge=0, le=86400)
        refresh: bool = False
        purpose: Literal['private_research', 'private_display'] = 'private_display'

    class Replay(BaseModel):
        model_config = ConfigDict(extra='forbid', strict=True)
        receipt_id: str = Field(pattern=r'^[a-f0-9-]{16,64}$')
        max_bytes: int = Field(default=64 * 1024 * 1024, ge=1, le=8 * 1024**3)
        timeout_seconds: int = Field(default=25, ge=1, le=300)
        purpose: Literal['private_research', 'private_display'] = 'private_display'

    class Reserve(BaseModel):
        model_config = ConfigDict(extra='forbid', strict=True)
        timeout_seconds: int = Field(default=25, ge=1, le=25)

    class Cooldown(BaseModel):
        model_config = ConfigDict(extra='forbid', strict=True)
        value: str | None = Field(default=None, max_length=128)

    api = FastAPI(title='DCC Shared SEC', docs_url=None, redoc_url=None, openapi_url=None)

    @api.middleware('http')
    async def security(request: Request, call_next):
        if request.headers.get('origin') or request.headers.get('host', '').split(':')[0] not in {'127.0.0.1', 'testserver'}:
            return JSONResponse({'error': {'code': 'forbidden', 'message': 'Shared SEC is a server-side loopback service.'}}, status_code=403)
        if request.url.path != '/health':
            app = authorize(request.headers.get('authorization'))
            if app is None:
                return JSONResponse({'error': {'code': 'unauthorized', 'message': 'Valid app credential required.'}}, status_code=401)
            request.state.sec_app = app
        return await call_next(request)

    @api.exception_handler(DataError)
    async def sdk_error(request: Request, error):
        status = {'not_found': 404, 'invalid_request': 422, 'wrong_issuer': 409,
                  'rights_denied': 403, 'policy_denied': 403, 'integrity_error': 409,
                  'quota_exhausted': 429, 'rate_limited': 429, 'response_too_large': 413}.get(error.code, 503)
        upstream = None
        retry_after = None
        try:
            source_url = (await request.json()).get('url')
            database = root / 'sec-raw/receipts.sqlite'
            with closing(sqlite3.connect(database.as_uri() + '?mode=ro', uri=True)) as db:
                row = db.execute('SELECT status,headers FROM receipt WHERE success=0 AND url=? ORDER BY completed DESC LIMIT 1', (source_url,)).fetchone()
            if row:
                upstream = row[0] if row[0] >= 400 else None
                retry_after = json.loads(row[1]).get('retry-after')
        except (OSError, sqlite3.Error, ValueError):
            pass
        # Provider URLs/bodies and service configuration are omitted from error responses.
        return JSONResponse({'error': {'code': error.code, 'message': f'Shared SEC acquisition failed ({error.code}).',
                                       'http_status': upstream, 'retry_after': retry_after}}, status_code=status)

    def result(client, artifact, *, body=True, max_bytes=64 * 1024 * 1024, delivery=None,
               purpose='private_display', timeout_seconds=25):
        item = {'schema_version': 'dcc-sec.response.v1', 'url': artifact.url, 'sha256': artifact.sha256,
                'receipt_id': artifact.receipt_id, 'retrieved_at': artifact.retrieved_at,
                'completed_at': artifact.completed_at, 'requested_at': artifact.requested_at,
                'status': artifact.status, 'delivery': delivery or artifact.delivery,
                'headers': artifact.headers, 'path': str(artifact.path)}
        if body:
            with client.open_content(artifact.receipt_id, purpose=purpose, max_bytes=max_bytes,
                                     timeout_seconds=timeout_seconds) as stream:
                content = stream.read(max_bytes + 1)
            if len(content) > max_bytes:
                raise DataError('response_too_large', 'SEC content exceeds the requested bound')
            item['body_base64'] = base64.b64encode(content).decode('ascii')
        else:
            # The SDK has validated the stored content during acquisition; file access remains same-user only.
            with client.open_content(artifact.receipt_id, purpose=purpose, max_bytes=max_bytes,
                                     timeout_seconds=timeout_seconds):
                pass
        item['served_at'] = datetime.now(timezone.utc).isoformat(timespec='microseconds').replace('+00:00', 'Z')
        return item

    @api.get('/health')
    def health():
        import importlib.metadata
        return {'status': 'ok', 'service': 'dcc-shared-sec', 'version': '0.1.1',
                'sdk_version': importlib.metadata.version('public-investment-data')}

    @api.post('/v1/fetch')
    def fetch(payload: Fetch):
        if payload.max_bytes > 64 * 1024 * 1024 or payload.timeout_seconds > 25:
            raise DataError('invalid_request', 'Use same-host file acquisition for larger SEC requests')
        client = raw()
        artifact = client.fetch(**payload.model_dump(exclude={'purpose'}))
        return result(client, artifact, max_bytes=payload.max_bytes, purpose=payload.purpose)

    @api.post('/v1/acquire-file')
    def acquire_file(payload: Fetch):
        client = raw()
        artifact = client.fetch(**payload.model_dump(exclude={'purpose'}))
        return result(client, artifact, body=False, max_bytes=payload.max_bytes, purpose=payload.purpose,
                      timeout_seconds=payload.timeout_seconds)

    @api.post('/v1/replay')
    def replay(payload: Replay):
        if payload.max_bytes > 64 * 1024 * 1024 or payload.timeout_seconds > 25:
            raise DataError('invalid_request', 'Use same-host file replay for larger SEC content')
        client = raw()
        artifact = client.replay(payload.receipt_id, timeout_seconds=payload.timeout_seconds)
        return result(client, artifact, max_bytes=payload.max_bytes, delivery='replay', purpose=payload.purpose)

    @api.post('/v1/replay-file')
    def replay_file(payload: Replay):
        client = raw()
        artifact = client.replay(payload.receipt_id, timeout_seconds=payload.timeout_seconds)
        return result(client, artifact, body=False, max_bytes=payload.max_bytes, delivery='replay',
                      purpose=payload.purpose, timeout_seconds=payload.timeout_seconds)

    @api.post('/v1/reserve')
    def reserve(payload: Reserve):
        raw()._reserve(time.monotonic() + payload.timeout_seconds)
        return {'reserved': True}

    @api.post('/v1/cooldown')
    def cooldown(payload: Cooldown):
        raw()._cooldown(payload.value)
        return {'recorded': True}

    return api


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('command', choices=['serve', 'init'])
    parser.add_argument('--home', type=Path, required=True)
    parser.add_argument('--port', type=int, default=8931)
    parser.add_argument('--project', action='append', default=[])
    args = parser.parse_args()
    if args.command == 'init':
        provision(args.home, dict(item.split('=', 1) for item in args.project), args.port)
    else:
        import uvicorn
        uvicorn.run(create_app(args.home), host='127.0.0.1', port=args.port, access_log=False)


if __name__ == '__main__':
    main()
