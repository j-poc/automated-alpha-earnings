from __future__ import annotations

import base64
import hashlib
import io
import json
import math
import os
import re
import stat
import time
import types
import urllib.error
import urllib.request
from contextlib import closing, contextmanager
from dataclasses import dataclass, replace
from datetime import datetime
from pathlib import Path
from urllib.parse import urlsplit

CAP = 64 * 1024 * 1024


class SharedSecError(RuntimeError):
    def __init__(self, code, message, http_status=None, retry_after=None):
        super().__init__(message)
        self.code = code
        self.status = self.http_status = http_status
        self.retry_after = retry_after
        self.headers = {'retry-after': str(retry_after)} if retry_after is not None else {}


@dataclass(frozen=True)
class Connection:
    url: str
    token: str
    app: str
    raw_root: Path | None
    quota_root: Path | None


@dataclass(frozen=True)
class SharedResponse:
    body: bytes
    url: str
    sha256: str
    retrieved_at: str
    completed_at: str
    requested_at: str
    status: int
    delivery: str
    receipt_id: str
    headers: dict
    served_at: str = ''
    path: Path | None = None


def connection(*, app: str, connection_path=None) -> Connection:
    if os.environ.get('DCC_SEC_URL') or os.environ.get('DCC_SEC_TOKEN'):
        data = {'url': os.environ.get('DCC_SEC_URL'), 'token': os.environ.get('DCC_SEC_TOKEN'), 'app': app}
    else:
        path = Path(connection_path or os.environ.get('DCC_SEC_CONNECTION') or '.dcc-sec.json').resolve()
        try:
            mode = path.stat()
            if mode.st_uid != os.getuid() or stat.S_IMODE(mode.st_mode) & 0o077:
                raise SharedSecError('configuration_error', 'SEC connection must be owner-only (0600).')
            data = json.loads(path.read_text())
        except (OSError, ValueError) as error:
            raise SharedSecError('configuration_error', 'Shared SEC connection is missing or invalid; no direct source fallback.') from error
        if data.get('app') != app:
            raise SharedSecError('configuration_error', 'Shared SEC connection belongs to another app.')
    url, token = data.get('url'), data.get('token')
    try:
        parsed = urlsplit(url)
        if (not isinstance(url, str) or parsed.username or parsed.password or parsed.path not in ('', '/')
                or parsed.query or parsed.fragment or not parsed.hostname
                or not (parsed.scheme == 'https' or parsed.scheme == 'http' and parsed.hostname == '127.0.0.1')):
            raise ValueError
        parsed.port
        if not isinstance(token, str) or not re.fullmatch(r'[A-Za-z0-9_-]{32,128}', token):
            raise ValueError
    except (ValueError, TypeError):
        raise SharedSecError('configuration_error', 'SEC service requires loopback HTTP or remote HTTPS and a valid token.') from None
    return Connection(url.rstrip('/'), token, app,
                      Path(data['raw_root']) if data.get('raw_root') else None,
                      Path(data['quota_root']) if data.get('quota_root') else None)


def archive_root(*, app):
    root = connection(app=app).raw_root
    if root is None:
        raise SharedSecError('configuration_error', 'This connection has no same-host raw archive.')
    return root


def quota_root(*, app):
    root = connection(app=app).quota_root
    if root is None:
        raise SharedSecError('configuration_error', 'This connection has no same-host quota archive.')
    return root


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        return None


def _call(config, route, payload, timeout=30, cap=CAP * 2):
    request = urllib.request.Request(config.url + route, json.dumps(payload).encode(),
                                     {'Authorization': 'Bearer ' + config.token, 'Content-Type': 'application/json'})
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), _NoRedirect())
    try:
        with opener.open(request, timeout=timeout) as response:
            data = response.read(cap + 1)
        if len(data) > cap:
            raise SharedSecError('response_too_large', 'Shared SEC response exceeds its bound.')
        return json.loads(data)
    except urllib.error.HTTPError as error:
        try:
            detail = json.loads(error.read(16384)).get('error', {})
        except (ValueError, AttributeError):
            detail = {}
        raise SharedSecError(detail.get('code', 'service_unavailable'),
                             detail.get('message', 'Shared SEC service rejected the request.'),
                             detail.get('http_status') or error.code, detail.get('retry_after')) from None
    except (urllib.error.URLError, TimeoutError, OSError, ValueError) as error:
        raise SharedSecError('service_unavailable', 'Shared SEC service is unavailable; retained app evidence remains unchanged.') from error


def _response(data, max_bytes, expected_url=None):
    try:
        if data['schema_version'] != 'dcc-sec.response.v1':
            raise ValueError
        body = base64.b64decode(data['body_base64'], validate=True)
        if len(body) > max_bytes or hashlib.sha256(body).hexdigest() != data['sha256']:
            raise ValueError
        if expected_url is not None and data['url'] != expected_url:
            raise ValueError
        if data['delivery'] not in {'network', 'cache', 'replay'} or data['status'] not in {200, 304}:
            raise ValueError
        if not re.fullmatch(r'[a-f0-9-]{16,64}', data['receipt_id']):
            raise ValueError
        for name in ('requested_at', 'retrieved_at', 'completed_at', 'served_at'):
            if datetime.fromisoformat(data[name].replace('Z', '+00:00')).tzinfo is None:
                raise ValueError
        return SharedResponse(body, data['url'], data['sha256'], data['retrieved_at'],
                              data['completed_at'], data['requested_at'], data['status'],
                              data['delivery'], data['receipt_id'], data['headers'],
                              data['served_at'],
                              Path(data['path']) if data.get('path') else None)
    except (KeyError, ValueError, TypeError) as error:
        raise SharedSecError('integrity_error', 'Shared SEC response identity, timestamps or bytes are invalid.') from error


def _ttl(value):
    if type(value) is not int or value < 0:
        raise SharedSecError('invalid_request', 'SEC cache TTL must be a nonnegative integer.')
    return min(value, 86400)


def _seconds(value, ceiling=25):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value <= 0:
        raise SharedSecError('invalid_request', 'SEC operation deadline must be positive and finite.')
    return max(1, min(ceiling, math.floor(value)))


def _fetch_bytes(config, url, *, max_bytes=CAP, timeout_seconds=25, ttl_seconds=300, refresh=False, purpose='private_display'):
    if type(max_bytes) is not int or not 1 <= max_bytes <= CAP:
        raise SharedSecError('invalid_request', 'SEC byte bound must be within 64 MiB.')
    timeout_seconds = _seconds(timeout_seconds)
    data = _call(config, '/v1/fetch',
                 {'url': url, 'max_bytes': max_bytes, 'timeout_seconds': timeout_seconds,
                  'ttl_seconds': _ttl(ttl_seconds), 'refresh': refresh, 'purpose': purpose}, timeout=timeout_seconds + 5,
                 cap=max_bytes * 2 + 32768)
    return _response(data, max_bytes, url)


def fetch_bytes(url, *, app, max_bytes=CAP, timeout_seconds=25, ttl_seconds=300, refresh=False,
                purpose='private_display', connection_path=None):
    return _fetch_bytes(connection(app=app, connection_path=connection_path), url,
                        max_bytes=max_bytes, timeout_seconds=timeout_seconds,
                        ttl_seconds=ttl_seconds, refresh=refresh, purpose=purpose)


def _file_response(data, config, max_bytes, expected_url=None):
    try:
        if (config.raw_root is None or data['schema_version'] != 'dcc-sec.response.v1'
                or not re.fullmatch(r'[a-f0-9]{64}', data['sha256'])
                or not re.fullmatch(r'[a-f0-9-]{16,64}', data['receipt_id'])
                or data['status'] not in {200, 304} or data['delivery'] not in {'network', 'cache', 'replay'}
                or expected_url is not None and data['url'] != expected_url):
            raise ValueError
        path = Path(data['path'])
        expected = config.raw_root / 'objects' / data['sha256']
        if path != expected or path.is_symlink() or path.parent.is_symlink() or not path.is_file() or path.stat().st_size > max_bytes:
            raise ValueError
        for field in ('requested_at', 'retrieved_at', 'completed_at', 'served_at'):
            if datetime.fromisoformat(data[field].replace('Z', '+00:00')).tzinfo is None:
                raise ValueError
        # The owner validates the retained object; independently bind the local file handle to its digest.
        digest = hashlib.sha256()
        with path.open('rb') as stream:
            while chunk := stream.read(1024 * 1024): digest.update(chunk)
        if digest.hexdigest() != data['sha256']:
            raise ValueError
        return types.SimpleNamespace(**{k: data[k] for k in ('url', 'sha256', 'retrieved_at', 'completed_at',
                                     'requested_at', 'served_at', 'status', 'delivery', 'receipt_id', 'headers')}, path=path)
    except (KeyError, TypeError, ValueError, OSError) as error:
        raise SharedSecError('integrity_error', 'Shared SEC file identity, locator, timestamps or digest is invalid.') from error


def _decorate(result):
    headers = {**result.headers, 'sec-raw-receipt': result.receipt_id,
               'sec-body-received-at': result.retrieved_at, 'sec-checked-at': result.completed_at,
               'sec-requested-at': result.requested_at, 'sec-served-at': result.served_at,
               'sec-delivery': result.delivery, 'sec-upstream-status': str(result.status)}
    if isinstance(result, SharedResponse): return replace(result, headers=headers)
    result.headers = headers
    return result


class SharedRawClient:
    def __init__(self, *, app, legacy_raw_roots=(), legacy_quota_roots=None, connection_path=None):
        self.app = app
        self.config = connection(app=app, connection_path=connection_path)
        self.root = self.config.raw_root
        self.quota_root = self.config.quota_root
        self.legacy_raw_roots = tuple(Path(p).resolve() for p in legacy_raw_roots if p is not None)
        self.legacy_quota_roots = {Path(k).resolve(): Path(v).resolve() for k, v in (legacy_quota_roots or {}).items()}

    def _translate(self, error):
        try:
            from public_investment_data import DataError
        except ImportError:
            raise error
        raise DataError(error.code, str(error)) from error

    def fetch(self, url, *, refresh=False, ttl_seconds=300, max_bytes=CAP, timeout_seconds=25, cancel_event=None):
        if cancel_event is not None and cancel_event.is_set():
            self._translate(SharedSecError('cancelled', 'SEC operation cancelled.'))
        try:
            if max_bytes is None:
                max_bytes = CAP
            if max_bytes <= CAP:
                result = _fetch_bytes(self.config, url, max_bytes=max_bytes,
                                      timeout_seconds=timeout_seconds, ttl_seconds=ttl_seconds, refresh=refresh)
            else:
                timeout_seconds = _seconds(timeout_seconds, 300)
                data = _call(self.config, '/v1/acquire-file',
                             {'url': url, 'max_bytes': max_bytes, 'timeout_seconds': timeout_seconds,
                              'ttl_seconds': _ttl(ttl_seconds), 'refresh': refresh}, timeout=timeout_seconds + 5)
                result = _file_response(data, self.config, max_bytes, url)
            return _decorate(result)
        except SharedSecError as error:
            self._translate(error)

    def _legacy(self, receipt_id):
        import sqlite3
        from public_investment_data.sec_raw import SecRawClient
        matches = []
        for root in self.legacy_raw_roots:
            path = root / 'receipts.sqlite'
            if not path.is_file() or root == self.root:
                continue
            with closing(sqlite3.connect(path.as_uri() + '?mode=ro', uri=True)) as db:
                row = db.execute('SELECT digest,url,retrieved FROM receipt WHERE id=? AND success=1', (receipt_id,)).fetchone()
            if row:
                matches.append((root, tuple(row)))
        if self.root is not None and (self.root / 'receipts.sqlite').is_file():
            with closing(sqlite3.connect((self.root / 'receipts.sqlite').as_uri() + '?mode=ro', uri=True)) as db:
                central = db.execute('SELECT digest,url,retrieved FROM receipt WHERE id=? AND success=1', (receipt_id,)).fetchone()
            if central is not None and matches and any(record != tuple(central) for _, record in matches):
                raise SharedSecError('integrity_error', 'Shared and historical SEC receipt identities conflict.')
        if len({record for _, record in matches}) > 1:
            raise SharedSecError('integrity_error', 'Ambiguous historical SEC receipt identity.')
        if matches:
            legacy_root = matches[0][0]
            candidates = [self.legacy_quota_roots[legacy_root]] if legacy_root in self.legacy_quota_roots else []
            candidates += [legacy_root.parent / '.sec-quota', legacy_root.parent / 'sec-quota', legacy_root.parent / 'quota']
            quota = next((p for p in candidates if (p / 'sec-quota.sqlite').is_file()), None)
            if quota is None:
                raise SharedSecError('configuration_error', 'Historical SEC replay requires its original quota-store location.')
            return SecRawClient(root=legacy_root, quota_root=quota,
                                user_agent='DCC historical replay dreamcllectr@gmail.com')
        raise SharedSecError('not_found', 'SEC receipt is absent from the shared and declared historical archives.', 404)

    def replay(self, receipt_id, *, timeout_seconds=25, cancel_event=None, max_bytes=None, purpose='private_display'):
        try:
            # Previously accepted receipts remain usable during a service outage.
            try:
                legacy = self._legacy(receipt_id)
            except SharedSecError as missing:
                if missing.code != 'not_found':
                    raise
            else:
                return legacy.replay(receipt_id, timeout_seconds=timeout_seconds, cancel_event=cancel_event)
            limit = max_bytes if max_bytes is not None else (8 * 1024**3 if self.root is not None else CAP)
            seconds = _seconds(timeout_seconds, 300 if self.root is not None else 25)
            route = '/v1/replay-file' if self.root is not None else '/v1/replay'
            data = _call(self.config, route, {'receipt_id': receipt_id, 'max_bytes': limit,
                                            'timeout_seconds': seconds, 'purpose': purpose}, timeout=seconds + 5)
            result = _file_response(data, self.config, limit) if self.root is not None else _response(data, limit)
            return _decorate(result)
        except SharedSecError as error:
            self._translate(error)

    @contextmanager
    def open_content(self, receipt_id, *, purpose='private_research', max_bytes=CAP, timeout_seconds=25, cancel_event=None):
        if purpose not in {'private_research', 'private_display'}:
            self._translate(SharedSecError('rights_denied', 'Shared raw SEC material is for private research/display.'))
        try:
            try:
                legacy = self._legacy(receipt_id)
            except SharedSecError as error:
                if error.code != 'not_found': raise
            else:
                with legacy.open_content(receipt_id, purpose=purpose, max_bytes=max_bytes,
                                         timeout_seconds=timeout_seconds, cancel_event=cancel_event) as stream:
                    yield stream
                return
            # The owner reauthorizes the exact requested purpose on every read.
            result = self.replay(receipt_id, timeout_seconds=timeout_seconds, cancel_event=cancel_event,
                                 max_bytes=max_bytes, purpose=purpose)
            if hasattr(result, 'body'):
                yield io.BytesIO(result.body)
            else:
                descriptor = os.open(result.path, os.O_RDONLY | os.O_NOFOLLOW)
                with os.fdopen(descriptor, 'rb') as stream: yield stream
        except SharedSecError as error:
            self._translate(error)

    def _reserve(self, deadline=None):
        try:
            timeout = max(1, min(25, int(deadline - time.monotonic()))) if deadline else 25
            _call(self.config, '/v1/reserve', {'timeout_seconds': timeout}, timeout=timeout + 5)
        except SharedSecError as error:
            self._translate(error)

    def _cooldown(self, value):
        try: _call(self.config, '/v1/cooldown', {'value': value})
        except SharedSecError as error: self._translate(error)


def raw_client(*, app, legacy_raw_roots=(), legacy_quota_roots=None, connection_path=None, **_):
    return SharedRawClient(app=app, legacy_raw_roots=legacy_raw_roots, legacy_quota_roots=legacy_quota_roots, connection_path=connection_path)


def bind_sdk(client, *, app, legacy_raw_roots=(), legacy_quota_roots=None, connection_path=None):
    historical = list(legacy_raw_roots)
    if getattr(client, 'sec_raw_root', None) is not None:
        historical.append(client.sec_raw_root)
    quotas = dict(legacy_quota_roots or {})
    if getattr(client, 'sec_raw_root', None) is not None and getattr(client, 'sec_quota_root', None) is not None:
        quotas[client.sec_raw_root] = client.sec_quota_root
    proxy = raw_client(app=app, legacy_raw_roots=historical, legacy_quota_roots=quotas, connection_path=connection_path)
    client.sec_raw_root, client.sec_quota_root = proxy.root, proxy.quota_root
    client._sec_client = types.MethodType(lambda self, user_agent=None: proxy, client)
    return client
